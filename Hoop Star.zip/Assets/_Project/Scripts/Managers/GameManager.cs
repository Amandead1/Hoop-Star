using System.Collections;
using UnityEngine.UI;
using UnityEngine;
using TMPro;

public class GameManager : MonoBehaviour
{
    [Header("Script References")]
    [SerializeField] WinningHoopManager winningHoopManager;

    [Header("UI References")]
    [SerializeField] TMP_Text playerScoreTextUI;
    [SerializeField] TMP_Text aiScoreTextUI;
   
    [Space(10)]
    [SerializeField] GameObject gameOverPanelObj;
    [SerializeField] TMP_Text winnerPanelTextUI;

    [Header("Gameobject Refernces")]
    [SerializeField] GameObject sparkleRainEffectObj;

    [Header("properties")]
    [SerializeField] int maxScoreToWin = 3;


    public int playerScore { get; private set; }
    public int aiScore { get; private set; }

    private void OnEnable()
    {
        BallPointOnGoal.OnHoopSuccess += UpdateScore;
    }

    private void OnDisable()
    {
        BallPointOnGoal.OnHoopSuccess -= UpdateScore;
    }

    public void UpdateScore(HoopId scoreBy)
    {        
        if (scoreBy == HoopId.Player) playerScore += 1;
        else if (scoreBy == HoopId.AI) aiScore += 1;

        UpdateScoreUI();
        CheckForWinner();
        GetWinningHoopId();

        sparkleRainEffectObj.SetActive(true);

    }

    void UpdateScoreUI()
    {
        playerScoreTextUI.text = playerScore +"";
        aiScoreTextUI.text = aiScore + "";
    }

    void CheckForWinner()
    {
        if(playerScore >= maxScoreToWin)
        {
            ShowWinnerPanel("You Won!");
            return;
        }

        if(aiScore >= maxScoreToWin)
        {
            ShowWinnerPanel("You Lost!");
        }
    }

    void ShowWinnerPanel(string winText)
    {
        winnerPanelTextUI.text = winText;
        Invoke(nameof(PauseGame), 0.4f);
    }

    void PauseGame()
    {
        gameOverPanelObj.SetActive(true);
        
        Time.timeScale = 0f;
    }
    
    public void GetWinningHoopId()
    {
        if (playerScore > aiScore)
        {
            winningHoopManager.HandleWinningCrownVisual(HoopId.Player);
            return;
        }
        if (aiScore > playerScore)
        {
            winningHoopManager.HandleWinningCrownVisual(HoopId.AI);
            return;
        }

        winningHoopManager.HandleWinningCrownVisual(HoopId.None);

    }
}
