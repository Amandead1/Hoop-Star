using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WinningHoopManager : MonoBehaviour
{
    
    [SerializeField] GameObject playerCrownVisual;
    [SerializeField] GameObject aiCrownVisual;
  
    public void HandleWinningCrownVisual(HoopId winningHoop)
    {    

        switch (winningHoop)
        {
            
            case HoopId.Player:

                playerCrownVisual.SetActive(true);
                aiCrownVisual.SetActive(false);

                break;
            case HoopId.AI:

                aiCrownVisual.SetActive(true);
                playerCrownVisual.SetActive(false);

                break;
            case HoopId.None:

                playerCrownVisual.SetActive(false);
                aiCrownVisual.SetActive(false);

                break;
        }
    }

}
