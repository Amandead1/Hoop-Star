using UnityEngine;

public class ShakeCameraOnCollision : MonoBehaviour
{
    [SerializeField] CameraShaker cameraShaker;

    private void OnCollisionEnter(Collision collision)
    {
        cameraShaker.DoCameraShake();
    }
}
