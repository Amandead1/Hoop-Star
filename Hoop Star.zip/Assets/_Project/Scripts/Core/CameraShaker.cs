using DG.Tweening;
using UnityEngine;

public class CameraShaker : MonoBehaviour
{
    [SerializeField] Camera cam;

    [Header("Settings")]
    [SerializeField] float shakeDuration;
    [SerializeField] Vector2 shakeStrength;
    [SerializeField] int vibrateStrength = 2;


    [ContextMenu("Shake Camera")]
    public void DoCameraShake()
    {
        cam.DOShakePosition(shakeDuration, shakeStrength, vibrateStrength, 10, true, ShakeRandomnessMode.Harmonic);
    }


}
