using UnityEngine;

public class HoopPhysics : MonoBehaviour
{
    [Header("References")]
    [SerializeField] Rigidbody rb;
    [SerializeField] HoopFeedback hoopFeedback;

    [Header("Settings")]
    [Tooltip("Range btw 20 to 50")]
    [SerializeField] float upwardForce = 5f;

    [Tooltip("Range btw 10 to 25")]
    [SerializeField] float sideForce = 5f;

    [SerializeField] float sideTorque = 10f;

    private float forceMultiplier = 1000f;

    public void ApplyPushForce(int sign)
    {
        print("Add Force!");

        // Resetting the velocity
        rb.velocity = Vector3.zero;

        // Adding the upward and sideward forces
        Vector3 forceToAdd = new Vector3(sideForce * sign, upwardForce, 0f);


        rb.AddForce(transform.up + forceToAdd * Time.fixedDeltaTime * forceMultiplier);

        //For adding a small amount of random Torque
        Vector3 torqueToAdd = new Vector3(0, 0, Random.Range(0, sideTorque));
        rb.AddTorque(torqueToAdd);

        //Play jump feedback
        hoopFeedback.ShowJumpFeedback();

        // Reseting the z position
        transform.position = new Vector3(transform.position.x, transform.position.y, 0);
    }

}
