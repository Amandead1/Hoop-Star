using UnityEngine;

public class HoopPivot : MonoBehaviour
{

    [SerializeField] Transform followTransform;
    [SerializeField] float yFollowOffset = 1.35f;


    Vector3 followOffset;

    private void Start()
    {
        transform.parent = null;
        followOffset = new Vector3(0, yFollowOffset, 0);
    }

    private void LateUpdate()
    {
        transform.position = followTransform.position + followOffset;
    }
}
