using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AiHoopPhysics : HoopPhysics
{

    [SerializeField] Transform centerBall;
    
    [Header("AI Settings")]
    [Range(0.8f,3f)]
    [SerializeField] float timeBtwShots = 1f;
    [SerializeField] float maxYHeight = 1.5f;
   

    void Start()
    {
        StartCoroutine(PerformAiHoopAction());
    }

    IEnumerator PerformAiHoopAction()
    {
        
        while (true)
        {
            int sign = DecideXMoveDirection();

            
            if (transform.position.y <= centerBall.position.y + maxYHeight)
            {
                base.ApplyPushForce(sign);
            }

            float randomShotTime = Random.Range(timeBtwShots - 0.5f, timeBtwShots + 0.3f);
            yield return new WaitForSeconds(randomShotTime);
        }
       
    }

    int DecideXMoveDirection()
    {
        
        // AI hoop is in left then add force in right
        if(transform.position.x < centerBall.position.x)
        {
            return 1;
        }

        return -1;
    }
}
