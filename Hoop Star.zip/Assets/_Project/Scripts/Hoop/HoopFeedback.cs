using System.Collections;
using UnityEngine;

public class HoopFeedback : MonoBehaviour
{
    [SerializeField] GameObject jumpFeedbackObj;
    [SerializeField] float hoopFlashDuration = 0.075f;
    
    public void ShowJumpFeedback()
    {
        StartCoroutine(ShowFlash());
    }

    IEnumerator ShowFlash()
    {
        jumpFeedbackObj.SetActive(true);
        yield return new WaitForSeconds(hoopFlashDuration);

        jumpFeedbackObj.SetActive(false);
    }
}
