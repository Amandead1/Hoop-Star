using UnityEngine;

public class HoopScore : MonoBehaviour
{

    public HoopId hoopId;
   
}

public enum HoopId
{
    Player,
    AI,
    None,
}
