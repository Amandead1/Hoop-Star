using System;
using UnityEngine;
using System.Collections;

public class BallPointOnGoal : MonoBehaviour
{
    public static Action<HoopId> OnHoopSuccess;

    [SerializeField] GameObject goalFeedbackVfx;

    bool canGoal = true;

    private void OnTriggerEnter(Collider col)
    {
        if (!canGoal) return;

        if (col.CompareTag("Hoop") == false) return;

        print("Successful Goal!");

        if (col.TryGetComponent<HoopScore>(out HoopScore score))
        {
            print("Score added to : " + score.hoopId);
            OnHoopSuccess?.Invoke(score.hoopId);

            StartCoroutine(PlayGoalFeedbacks());
        }
    }

    IEnumerator PlayGoalFeedbacks()
    {
        StopCoroutine(PlayGoalFeedbacks());

        goalFeedbackVfx.SetActive(true);

        yield return new WaitForSeconds(0.5f);

        goalFeedbackVfx.SetActive(false);
    }
}
